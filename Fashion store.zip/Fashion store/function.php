<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Poppins:100,200,300,400,500,600,700,800,900&display=swap" rel="stylesheet">

    <title>Hexashop Ecommerce php CSS Template</title>


    <!-- Additional CSS Files -->
    <link rel="stylesheet" type="text/css" href="assets/css/bootstrap.min.css">

    <link rel="stylesheet" type="text/css" href="assets/css/font-awesome.css">

    <link rel="stylesheet" href="assets/css/templatemo-hexashop.css">

    <link rel="stylesheet" href="assets/css/owl-carousel.css">

    <link rel="stylesheet" href="assets/css/lightbox.css">

    <?php
	
	$con = mysqli_connect("localhost","root","","fashiondb");

	//getting the brands from brands table.
	function getBrands()
	{
		global $con;
		$get_brand = "SELECT * FROM 'brands'";
		$run_brand = mysqli_query($con,$get_brand);
		while($row_brand = mysqli_fetch_array($run_brand))
		{
			$b_id = $row_brand['b_id'];
			$b_title = $row_brand['b_title'];
			echo "<li><a href='index.php?brand=$b_title'>$b_title</a></li>";
		}
	}

	//getting the products from product table.
	function getProduct()
	{
	  if(!isset($_GET['brand']))
	  {
		global $con;
		$get_pro = "SELECT * FROM product order by rand()";
		$run_pro = mysqli_query($con,$get_pro);
		while($row_pro = mysqli_fetch_array($run_pro))
		{ 
			$pro_id = $row_pro['p_id'];
			$pro_brand = $row_pro['p_brand'];
			$pro_model = $row_pro['p_model'];
			$pro_price = $row_pro['p_price'];
			$pro_image = $row_pro['p_image'];
			echo " 
			<div class='article'>		
                <div class='item'>
                    <div class='thumb'>
                        <div class='hover-content'>
                            <ul>
                                <li><a href='buy.php?buy_pro=$pro_id'><img src='images/icon.png' alt=''></a></li>
                            </ul>
                        </div>
                        <img src='admin/product_images/$pro_image' width='350px' height='400px'>
                    </div>
                    <div class='down-content'>
                        <h4>$pro_model</h4>
                        <span>$pro_price</span>
                    </div>
                </div>
            </div>
			
			
			
			";
			
		}
	  }
	}
	
	function getBrandPro()
	{
	  if(isset($_GET['brand']))
	  {
		global $con;
		$brand_title = $_GET['brand'];
		$get_brand_pro = "SELECT * FROM product WHERE p_brand='$brand_title'";
		$run_brand_pro = mysqli_query($con,$get_brand_pro);
		while($row_brand_pro = mysqli_fetch_array($run_brand_pro))
		{ 
			$pro_id = $row_brand_pro['p_id'];
			$pro_brand = $row_brand_pro['p_brand'];
			$pro_model = $row_brand_pro['p_model'];
			$pro_price = $row_brand_pro['p_price'];
			$pro_image = $row_brand_pro['p_image'];
			echo " 
				
            <div class='article'>
                <div class='item'>
                    <div class='thumb'>
                        <div class='hover-content'>
                            <ul>
                                <li><a href='signin.php?buy_pro=$pro_id'><img src='images/icon.png' alt=''></a></li>
                            </ul>
                        </div>
                        <img src='admin/product_images/$pro_image' width='350px' height='400px'>
                    </div>
                    <div class='down-content'>
                        <h4>$pro_model</h4>
                        <span>$pro_price</span>
                    </div>
                </div>
			</div>
			
			
			";
			
		}
	  }
	}
	
	
	
?>

    
    <script src="assets/js/jquery-2.1.0.min.js"></script>

    <!-- Bootstrap -->
    <script src="assets/js/popper.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>

    <!-- Plugins -->
    <script src="assets/js/owl-carousel.js"></script>
    <script src="assets/js/accordions.js"></script>
    <script src="assets/js/datepicker.js"></script>
    <script src="assets/js/scrollreveal.min.js"></script>
    <script src="assets/js/waypoints.min.js"></script>
    <script src="assets/js/jquery.counterup.min.js"></script>
    <script src="assets/js/imgfix.min.js"></script> 
    <script src="assets/js/slick.js"></script> 
    <script src="assets/js/lightbox.js"></script> 
    <script src="assets/js/isotope.js"></script> 
    
    <!-- Global Init -->
    <script src="assets/js/custom.js"></script>

    <script>

        $(function() {
            var selectedClass = "";
            $("p").click(function(){
            selectedClass = $(this).attr("data-rel");
            $("#portfolio").fadeTo(50, 0.1);
                $("#portfolio div").not("."+selectedClass).fadeOut();
            setTimeout(function() {
              $("."+selectedClass).fadeIn();
              $("#portfolio").fadeTo(50, 1);
            }, 500);
                
            });
        });

    </script>

  </body>
</php>