<!DOCTYPE php>
    <php lang="en">
      <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<link rel="stylesheet" href="assets/css/style.css">
  <title>Admin page</title>


    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-lugx-gaming.css">
    <link rel="stylesheet" href="assets/css/owl.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet"href="https://unpkg.com/swiper@7/swiper-bundle.min.css"/>
    <link rel="stylesheet" href="tooplate_style.css">
<!-- CuFon ends -->

</head>

<?php
	error_reporting(1);
	if($_REQUEST['log']=='out')
	{
		session_destroy();
		header("location:index.php");
	}
?>
<body>

<div id="js-preloader" class="js-preloader">
    <div class="preloader-inner">
      <span class="dot"></span>
      <div class="dots">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
  </div>
<div class="main">
<header class="header-area header-sticky">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <nav class="main-nav">
                    <!-- ***** Logo Start ***** -->
                    <a href="index.php" class="logo">
                        <img src="assets/images/logo.png" alt="" style="width: 158px;">
                    </a>
                    <!-- ***** Logo End ***** -->
                    <!-- ***** Menu Start ***** -->
                    <ul class="nav">
                    <li><a href="home.php" class="active">Home</a></li>
                      <li><a href="view_product.php">View Product</a></li>
                      <li><a href="insert_product.php">Add Product</a></li>
                      <li><a href="view_order.php">View Order</a></li>
                      <li><a href="feedback.php">Feedback</a></li>
                      <li><a href="?log=out">Log Out</a></li>
                  </ul>   
                    <a class='menu-trigger'>
                        <span>Menu</span>
                    </a>
                    <!-- ***** Menu End ***** -->
                </nav>
            </div>
        </div>
    </div>
  </header>

  
  <div class="main-banner">
    <div class="container">
    <section class="ftco-section">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-6 text-center mb-5">
					<h2 class="heading-section">All Order</h2>
				</div>
			</div>

			<div class="row">
				<div class="col-md-12">
					<div class="table-wrap">
						<?php
				error_reporting(1);
	
				include("dbconnect.php");
	
				$view = "SELECT * FROM buy";
				$result = mysqli_query($con, $view);
				
				echo "<table class='table table-bordered table-dark table-hover'>";
				echo "<tr>
						  <th>Brand</th>
					  	  <th>Model</th>
					  	  <th>Price</th>
					  	  <th>Phone</th>
						  <th>Delivery</th>
						  <th>Address</th>
						  <th>Order_no</th>
					  </tr>
					 ";
				
				while(list($b,$m,$p,$phno,$delivery,$add,$order_no) = mysqli_fetch_array($result))
				{
					echo "<tr align='center'>";
					echo "<td>". $b ."</td>";
					echo "<td>". $m ."</td>";
					echo "<td>". $p ."</td>";
					echo "<td>". $phno ."</td>";
					echo "<td>". $delivery ."</td>";
					echo "<td>". $add ."</td>";
					echo "<td>". $order_no ."</td>";
					echo "</tr>";
				}
				echo "</table>";
		  ?>
					</div>
				</div>
			</div>
		</div>
	</section>
    </div>
  </div>

  <div class="features">
    <div class="container">
      <div class="row">
        <div class="col-lg-3 col-md-6">
          <a href="view_product.php">
            <div class="item">
              <div class="image">
                <img src="assets/images/feature-01.png" alt="" style="max-width: 70px;">
              </div>
              <h4>View Product</h4>
            </div>
          </a>
        </div>
        <div class="col-lg-3 col-md-6">
          <a href="view_order.php">
            <div class="item">
              <div class="image">
                <img src="assets/images/feature-02.png" alt="" style="max-width: 70px;">
              </div>
              <h4>View Order</h4>
            </div>
          </a>
        </div>
        <div class="col-lg-3 col-md-6">
          <a href="feedback.php">
            <div class="item">
              <div class="image">
                <img src="assets/images/feature-03.png" alt="" style="max-width: 70px;">
              </div>
              <h4>Feedback</h4>
            </div>
          </a>
        </div>
        <div class="col-lg-3 col-md-6">
          <a href="?log=out">
            <div class="item">
              <div class="image">
                <img src="assets/images/feature-04.png" alt="" style="max-width: 70px;">
              </div>
              <h4>Log Out</h4>
            </div>
          </a>
        </div>
      </div>
    </div>
  </div>
  
  <footer>
    <div class="container">
      <div class="col-lg-12">
        <p>Copyright © 2048 LUGX Gaming Company. All rights reserved. &nbsp;&nbsp; <a rel="nofollow" href="https://templatemo.com" target="_blank">Design: TemplateMo</a></p>
      </div>
    </div>
  </footer>
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.min.js"></script>
  <script src="assets/js/isotope.min.js"></script>
  <script src="assets/js/owl-carousel.js"></script>
  <script src="assets/js/counter.js"></script>
  <script src="assets/js/custom.js"></script>
  <script src="assets/js/jquery.min.js"></script>
  <script src="assets/js/popper.js"></script>
  <script src="assets/js/bootstrap.min.js"></script>
  <script src="assets/js/main.js"></script>

</div>
</body>
</html>
